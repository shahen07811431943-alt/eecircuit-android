---
name: Bug Report
about: Describe this issue template's purpose here.
title: ''
labels: ''
assignees: ''

---

✋  !! Only for bug reports. Please use the [Discussions](https://github.com/eelab-dev/EEcircuit/discussions) for a feature request ✋
